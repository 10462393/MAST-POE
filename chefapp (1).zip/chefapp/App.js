import React, { useState } from 'react';
import { Button, Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
const Stack = createStackNavigator();

function WelcomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Image 
        source={require('./assets/logo.png')} 
        style={styles.image}
      />
      <View style={styles.welcomeButtonContainer}>
        <Button 
          title="WELCOME"
          onPress={() => navigation.navigate('LoginScreen')}
          color="red"
        />
      </View>
    </View>
  );
}

function LoginScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Image 
        source={require('./assets/logo.png')} 
        style={styles.image}
      />
      <View style={styles.buttonContainer}>
        <Button 
          title="CHEF" 
          onPress={() => navigation.navigate('ChefScreen')} 
          color="red"
        />
        <Button 
          title="CLIENT 1" 
          onPress={() => {}} 
          color="red"  
        />
        <Button 
          title="CLIENT 2" 
          onPress={() => {}} 
          color="red" 
        />
      </View>
    </View>
  );
}

function ChefScreen({navigation}) {
  const [meals, setMeals] = useState([
    { 
      id: 1, 
      name: 'Cheese Pasta', 
      price: 50, 
      type: 'Main',
      img: require('./assets/meal.jpeg') 
    },
    {
      id: 2,
      name: 'Lamb chop, honey-based sauce & sun-dried potato',
      price: 97,
      type: 'Main',
      img: require('./assets/meal1.jpeg')
    },
    {
      id: 3,
      name: 'Fish, egg & avocado salad',
      price: 62,
      type: 'Appetizer',
      img: require('./assets/meal2.jpeg')
    },
    {
      id: 4,
      name: 'Creamy white sauce with vegetables',
      price: 47,
      type: 'Appetizer',
      img: require('./assets/meal3.jpeg')
    },
    {
      id: 5,
      name: '6 piece sesame chicken wings glazed in honey and garlic',
      price: 43,
      type: 'Main',
      img: require('./assets/meal4.jpeg')
    },
    {
      id: 6,
      name: 'Nachos patty topped with avocado',
      price: 35,
      type: 'Main',
      img: require('./assets/meal5.jpeg')
    },
     {
      id: 7,
      name: 'Bluberry Waffles',
      price: 34,
      type: 'Dessert',
      img: require('./assets/meal6.jpeg')
    },
    {
        id: 8,
        name: 'Beef chops sprinkled with bay leaves',
        price: 95,
        type: 'Main',
        img: require('./assets/meal7.jpeg')
      },
 {
        id: 9,
        name: 'Roasted celeriac', 
        price: 39,
        type: 'Appetizer',
        img: require('./assets/meal9.jpeg')
      },
       {
        id: 10,
        name: 'On the rocks', 
        price: 30,
        type: 'Beverage',
        img: require('./assets/meal10.jpeg')
      },
       {
        id: 11,
        name: 'Strawberry Cake', 
        price: 39,
        type: 'Dessert',
        img: require('./assets/meal11.jpeg')
      },
     {
        id: 12,
        name: 'Mint biscuit with lemon', 
        price: 25,
        type: 'Dessert',
        img: require('./assets/meal12.jpeg')
      },
  ]);

  const addMeal = () => {
    const predefinedMeals = [ 
      { 
      id: 1, 
      name: 'Cheese Pasta', 
      price: 50, 
      type: 'Main',
      img: require('./assets/meal.jpeg') 
    },
    {
      id: 2,
      name: 'Lamb chop, honey-based sauce & sun-dried potato',
      price: 97,
      type: 'Main',
      img: require('./assets/meal1.jpeg')
    },
    {
      id: 3,
      name: 'Fish, egg & avocado salad',
      price: 62,
      type: 'Appetizer',
      img: require('./assets/meal2.jpeg')
    },
    {
      id: 4,
      name: 'Creamy white sauce with vegetables',
      price: 47,
      type: 'Appetizer',
      img: require('./assets/meal3.jpeg')
    },
    {
      id: 5,
      name: '6 piece sesame chicken wings glazed in honey and garlic',
      price: 43,
      type: 'Main',
      img: require('./assets/meal4.jpeg')
    },
    {
      id: 6,
      name: 'Nachos patty topped with avocado',
      price: 35,
      type: 'Main',
      img: require('./assets/meal5.jpeg')
    },
     {
      id: 7,
      name: 'Bluberry Waffles',
      price: 34,
      type: 'Dessert',
      img: require('./assets/meal6.jpeg')
    },
    {
        id: 8,
        name: 'Beef chops sprinkled with bay leaves',
        price: 95,
        type: 'Main',
        img: require('./assets/meal7.jpeg')
      },
 {
        id: 9,
        name: 'Roasted celeriac', 
        price: 39,
        type: 'Appetizer',
        img: require('./assets/meal9.jpeg')
      },
       {
        id: 10,
        name: 'On the rocks', 
        price: 30,
        type: 'Beverage',
        img: require('./assets/meal10.jpeg')
      },
       {
        id: 11,
        name: 'Strawberry Cake', 
        price: 39,
        type: 'Dessert',
        img: require('./assets/meal11.jpeg')
      },
     {
        id: 12,
        name: 'Mint biscuit with lemon', 
        price: 25,
        type: 'Dessert',
        img: require('./assets/meal12.jpeg')
      },
    ];

    const randomMeal = predefinedMeals[Math.floor(Math.random() * predefinedMeals.length)];
    setMeals([...meals, randomMeal]);
  };

  const removeMeal = (id) => {
    setMeals(meals.filter(meal => meal.id !== id)); 
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        {meals.map((meal) => (
          <View key={meal.id} style={styles.mealContainer}>
            <Image source={meal.img} style={styles.mealImage} />
            <View style={styles.mealDetails}>
              <Text style={styles.mealTitle}>{meal.name}</Text>
              <Text style={styles.mealPrice}>R{meal.price}</Text>
              <Text style={styles.mealType}>{meal.type}</Text>
              <View style={styles.buttonRow}>
                <Button title="Remove" 
                onPress={() => removeMeal(meal.id)} 
                color="red" 
                />
                <View style={styles.buttonSpacing} />
                <Button title="Add" onPress={addMeal} color="red" />
              </View>
            </View>
          </View>
        ))}
        {meals.length === 0 && ( // Code to display no meals
          <Text style={styles.noMealsText}>No meals available</Text>
        )}
      </ScrollView>
      
      <View style={styles.saveButtonContainer}>
      <Button
      title="Save"
      onPress={() => navigation.navigate('LoginScreen')}
      color="red"
      />
    </View>
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="WelcomeScreen">
        <Stack.Screen name="WelcomeScreen" component={WelcomeScreen} />
        <Stack.Screen name="LoginScreen" component={LoginScreen} />
        <Stack.Screen name="ChefScreen" component={ChefScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  image: {
    width: 350,
    height: 350,
    marginBottom: 30,
  },
  welcomeButtonContainer: {
    width: 250, 
    borderRadius: 100, 
    overflow: 'hidden', 
  },
  buttonContainer: {
    justifyContent: 'space-around',
    flexDirection: 'column',
    width: 250,
    height: '50%' ,
  },
  buttonRow:{
    flexDirection: 'row',
    marginTop: 15,
    padding: 20,
  },
  buttonSpacing: {
    height: 30, 
    width: 30,
  },
  scrollViewContent: {
    flexGrow: 1,
    alignItems: 'center',
  },
  mealContainer: {
    flexDirection: 'column', 
    marginVertical: 10,
    padding: 30,
    borderRadius: 8,
    width: '90%', 
    alignItems: 'center', 
  },
  mealImage: {
    width: 200,
    height: 200,
    marginBottom: 10, 
  },
  mealDetails: {
    alignItems: 'center', 
    paddingHorizontal: 10,
  },
  mealTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  mealPrice: {
    fontSize: 16,
    color: 'black',
  },
   mealType: {
    fontSize: 16,
    color: 'black',
  },
  noMealsText: {
    fontSize: 18,
    color: 'gray',
    textAlign: 'center',
    marginVertical: 20,
  },
  saveButtonContainer: {
    marginVertical: 20,
    width: '90%',
  },
});
